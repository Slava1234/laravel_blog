@extends('main')

@section('title', 'About us')


@section('content')
    <div class="row">
        <div class="col-md-12">
            <h1>Abount me</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium consequatur, minus mollitia nisi numquam similique temporibus totam unde voluptas. Amet aut autem beatae cum eos, eveniet fugit quod. Aperiam, porro?</p>
        </div>
    </div>
@endsection
