<?php $__env->startSection('title', 'View post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <h1><?php echo e($post->title); ?></h1>
            <p class="lead"><?php echo $post->body; ?></p>
        </div>

        <div class="col-md-4">
            <div class="well">
                <dl class="dl-horizontal">
                    <dt>Слог:</dt>
                    <dd><a href="<?php echo e(url('blog').'/'.$post->slug); ?>"><?php echo e($post->slug); ?></a></dd>
                </dl>
                <dl class="dl-horizontal">
                    <dt>Категория:</dt>
                    <dd><?php echo e($post->category->name); ?></dd>
                </dl>

                <dl class="dl-horizontal">
                    <dt>Создан:</dt>
                    <dd><?php echo e(date('M j, Y H:i', strtotime($post->created_at))); ?></dd>
                </dl>
                <dl class="dl-horizontal">
                    <dt>Обновлен:</dt>
                    <dd><?php echo e(date('M j, Y H:i', strtotime($post->updated_at))); ?></dd>
                </dl>
                <hr>
                <div class="row">
                    <div class="col-sm-6">
                        <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-primary btn-block btn-sm">Редактировать</a>
                    </div>
                    <div class="col-sm-6">
                        <?php echo Form::open(["route" => ["posts.destroy", $post->id], "method" => "DELETE"]); ?>

                            <?php echo Form::submit("Удалить", ["class" => "btn btn-danger btn-block btn-sm"]); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?php echo e(Html::linkRoute('posts.index', '<< Назад', [], ['class' => 'btn btn-default btn-block btn-h1-spacing'])); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>