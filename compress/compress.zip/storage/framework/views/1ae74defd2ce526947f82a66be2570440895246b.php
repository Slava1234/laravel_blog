<?php $__env->startSection('title', 'Новые комментарии'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
      <h2>Новые комментарии</h2>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>id</th>
            <th>Пользователь</th>
            <th>E-mail пользователя</th>
            <th>Название поста</th>
            <th>Комментарий</th>
            <th>Дата добавления</th>
            <th>Действие</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $newComments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($comment->id); ?></td>
                    <td><?php echo e($comment->name); ?></td>
                    <td><?php echo e($comment->email); ?></td>
                    <td><a href="<?php echo e(url('./blog/'.$comment->post->slug)); ?>"><?php echo e($comment->post->title); ?></a></td>
                    <td><?php echo e($comment->comment); ?></td>
                    <td><?php echo e($comment->created_at); ?></td>
                    <td>
                        <?php echo e(Form::open(['route' => ['comments.destroy', $comment->id], 'method' => 'DELETE'])); ?>

                            <input class="btn btn-danger btn-xs" type="submit" value="Удалить">
                        <?php echo e(Form::close()); ?>


                        <?php echo e(Form::open(['route' => ['comments.update', $comment->id], 'method' => 'PUT'])); ?>

                            <input type="submit" class="btn btn-success btn-xs" value="Утвердить">
                        <?php echo e(Form::close()); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>