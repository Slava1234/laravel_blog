<html>
    <head>
        <title>404</title>
         <link href="<?php echo e(url('public/css/bootstrap/bootstrap.min.css')); ?>" rel="stylesheet">
    </head>

<body>
    <div class="row">
        <div class="col-md-12">
            <h1>Ошибка <b style="color: red">404</b> страница не найдена</h1>
        </div>
    </div>
</body>

</html>
