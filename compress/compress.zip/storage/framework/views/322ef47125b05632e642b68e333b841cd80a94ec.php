<?php $__env->startSection('title', 'About us'); ?>


<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Abount me</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium consequatur, minus mollitia nisi numquam similique temporibus totam unde voluptas. Amet aut autem beatae cum eos, eveniet fugit quod. Aperiam, porro?</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>