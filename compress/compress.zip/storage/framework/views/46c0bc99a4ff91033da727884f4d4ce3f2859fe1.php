<?php $__env->startSection('title', 'Поиск'); ?>

<?php $__env->startSection('content'); ?>

    <!--Поиск-->
    <?php echo Form::open(['route' => 'admin.post.search' , 'method' => 'get']); ?>

        <div class="col-lg-4 margin-top-15">
            <div class="input-group">
              <input type="text" <?php if(isset($_GET['q'])): ?>value="<?php echo e($_GET['q']); ?>" <?php endif; ?> name="q" class="form-control" placeholder="Поиск...">
              <span class="input-group-btn">
                <input type="submit" class="btn btn-default" value="Найти">
              </span>
            </div><!-- /input-group -->
        </div><!-- /.col-lg-6 -->
    <?php echo Form::close(); ?>


    <div class="row">
        <div class="col-md-12 form-spacing-top">
            <table class="table">
                <thead>
                    <th>id</th>
                    <th>Название</th>
                    <th>Текст</th>
                    <th>Дата создания</th>
                    <th></th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $searchResult; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th><?php echo e($post->id); ?></th>
                            <td><?php echo e($post->title); ?></td>
                            <td><?php echo e(substr(strip_tags($post->body), 0, 50)); ?><?php echo e(strlen(strip_tags($post->body))>50 ? '...':''); ?></td>
                            <td><?php echo e($post->created_at); ?></td>
                            <td>
                                <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-sm btn-default">View</a>
                                <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-sm btn-default">Edit</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>