<?php $__env->startSection('title', "| All categories"); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-md-12">
			<h1><?php echo e($category->name); ?></h1>
		</div>
		<div class="col-md-4 form-spacing-top">
			<div class="well">
				<!-- this form is automatically assum it post request -->
				<form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('categories.update')); ?>">
                        <?php echo e(csrf_field()); ?>

					<h2>Переименовать</h2>
					<label for="name">Новое название категории:</label>
					<input type="text" name="name" class="form-control" placeholder="<?php echo e($category->name); ?>">
					<?php echo e(Form::submit('Переименовать категорию', ['class' => 'btn btn-primary btn-block btn-h1-spacing'])); ?>

				</form>
			</div>
		</div>
        <div class="col-md-4 form-spacing-top">
            <div class="well">
                <!-- this form is automatically assum it post request -->
                <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('categories.store')); ?>">
                        <?php echo e(csrf_field()); ?>

                    <h2>Удалить эту категоию</h2>
                    <?php echo e(Form::submit('Удалить', ['class' => 'btn btn-danger btn-block btn-h1-spacing'])); ?>

                </form>
            </div>
        </div>
        <div class="col-md-4 form-spacing-top">
                <a href="<?php echo e(route('categories.index')); ?>" class="btn btn-default btn-block">Отмена</a>
        </div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>