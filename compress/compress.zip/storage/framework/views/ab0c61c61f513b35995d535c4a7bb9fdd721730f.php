<?php $title = htmlspecialchars($post->title); ?>
<?php $__env->startSection('title', "| $title"); ?>

<?php $__env->startSection('content'); ?>
	<div class="row col-md-8 col-md-offset-2">
		<h1><?php echo e($post->title); ?></h1>
		<p><?php echo $post->body; ?></p>
		<hr>
		<p>Категория:
			<a href="<?php echo e(route('category.index', $post->category->name )); ?>">
				<?php echo e($post->category->name); ?>

			</a>
		</p>
	</div>

	<div class="row">
		<div id="comment-form" class="col-md-8 col-md-offset-2 form-spacing-top">

			<?php echo e(Form::open(['route' => 'post.comment', 'method' => 'POST'])); ?>

				<input type="text" hidden name="post_id" value="<?php echo e($post->id); ?>">
				<div class="row">
					<div class="col-md-6">
						<?php echo e(Form::label('name', 'Имя:')); ?>

						<?php echo e(Form::text('name', null, ['class' => 'form-control'])); ?>

					</div>
					<div class="col-md-6">
						<?php echo e(Form::label('email', 'Email:')); ?>

						<?php echo e(Form::text('email', null, ['class' => 'form-control'])); ?>

					</div>
					<div class="col-md-12">
						<?php echo e(Form::label('comment', 'Комментарий:')); ?>

						<?php echo e(Form::textarea('comment', null, ['rows' => 5,'class' => 'form-control'])); ?>

						<?php echo e(Form::submit('Добавить комментарий', ['id' => 'create_comment','class' => 'btn btn-success btn-block btn-h1-spacing'])); ?>

					</div>
				</div>
			<?php echo e(Form::close()); ?>

		</div>
	</div>

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<p class="comments-title">
				<?php echo e($post->comments()->where('approved', 1)->count()); ?>

				Комментариев
			</p>
			<?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($comment->approved == 1): ?>
					<div class="comment">
						<div class="autor-info">
							<div class="author-name">
								<h4><?php echo e($comment->name); ?></h4>
								<p class="author-time">
									<?php echo e(date('F nS, Y - G:i', strtotime($comment->created_at))); ?>

								</p>
							</div>
						</div>
						<div class="comment-content">
							<?php echo e($comment->comment); ?>

						</div>
					</div>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>