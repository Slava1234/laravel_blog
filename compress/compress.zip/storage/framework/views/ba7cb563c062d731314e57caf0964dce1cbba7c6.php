<?php $__env->startSection('title', "| All categories"); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">

		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
			  <div class="panel-heading"><h4>Категория: <?php echo e($category->name); ?></h4></div>
			  <div class="panel-body">
				  <div class="col-md-8 col-md-offset-2">
					  <?php echo Form::open(['route' => ['categories.update', $category->id], "method" => "PUT"]); ?>

						  <?php echo e(Form::label('name', 'Переименовать эту категорию: ')); ?>

						  <?php echo e(Form::text('name', null, ["class" => "form-control"])); ?>

						  <?php echo e(Form::submit('Переименовать', ['class' => 'btn btn-primary btn-block btn-h1-spacing'])); ?>

					  <?php echo Form::close(); ?>

					  <hr>
				  		<?php echo Form::open(['route' => ['categories.destroy', $category->id], "method" => "DELETE"]); ?>

				  			<h4>Удалить эту категорию</h4>
				  			<h5>Вместе с категорией удалятся все посты в этой категрии</h5>
				  			<?php echo e(Form::submit('Удалить', ['class' => 'btn btn-danger btn-block btn-h1-spacing'])); ?>

				  		<?php echo Form::close(); ?>

				  		<hr>
				  		<a href="<?php echo e(route('categories.index')); ?>" class="btn btn-default btn-block">Отмена</a>
					</div>
			  </div>
			</div>
		</div>




	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>