<?php echo Form::open(['url' => 'foo/bar']); ?>

    <?php echo e(Form::text('username')); ?>

<?php echo Form::close(); ?>


