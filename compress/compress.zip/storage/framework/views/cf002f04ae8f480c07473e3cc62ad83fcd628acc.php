<?php $__env->startSection('title', "| All categories"); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">


		<div class="col-md-8">
			<div class="panel panel-default">
			  <div class="panel-heading"><h4>Список категорий</h4></div>
			  <div class="panel-body">
				  <table class="table">
						  <thead>
							  <tr>
								  <th>id</th>
								  <th>Название</th>
							  </tr>
						  </thead>
						  <tbody>
							  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  <tr>
									  <th><?php echo e($category->id); ?></th>
									  <td><a href="<?php echo e(route('categories.edit', $category->id)); ?>"><?php echo e($category->name); ?></a></td>
								  </tr>
							  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						  </tbody>
				  </table>

			  </div>
			</div>
		</div>


		<div class="col-md-4">
			<div class="well">
				<!-- this form is automatically assum it post request -->
				<form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('categories.store')); ?>">
                        <?php echo e(csrf_field()); ?>


					<h4>Создать новую категорию</h4>
					<label for="name">Название категории:</label>
					<input type="text" name="name" class="form-control">
					<?php echo e(Form::submit('Создать', ['class' => 'btn btn-success btn-block btn-h1-spacing'])); ?>

				</form>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>