<?php $__env->startSection('title', 'Create new post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <h3>Создание нового поста</h3>
            <hr>
            <?php echo Form::open(['route' => 'posts.store', 'files' => true]); ?>

                <?php echo e(Form::label('slug', 'URL Слог: ')); ?>

                <?php echo e(Form::text('slug', null, ["class" => "form-control", 'required'=>'', 'minlength' => '5', 'maxlength' => '255'])); ?>


                <?php echo e(Form::label('category_id', 'Категория: ', ['class' => 'btn-h1-spacing'])); ?>

                <select class="form-control" name="category_id">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php echo e(Form::label('feautred_image', 'Загрузить изображение', ['class' => 'btn-h1-spacing'])); ?>

                <?php echo e(Form::file('feautred_image')); ?>


                <label class="btn-h1-spacing" for="title">Название: </label>
                <input type="text" name="title" id="title" class="form-control">

                <label class="btn-h1-spacing" for="body">Текст: </label>
                <textarea name="body" rows="10" id="body" class="form-control"></textarea>

                <input type="submit" id="submit_create_post_form" value="Создать пост" style="margin-top: 20px" class="btn btn-success btn-lg btn-block">
                <input name="image" type="file" id="upload" class="hidden" onchange="">

                <?php echo e(csrf_field()); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('public/tinymce/tinymce.min.js')); ?>"></script>
    <script>
      tinymce.init({
        selector: "textarea",
        theme: "modern",
        paste_data_images: true,
        plugins: [
          "advlist autolink lists link image charmap print preview hr anchor pagebreak",
          "searchreplace wordcount visualblocks visualchars code fullscreen",
          "insertdatetime media nonbreaking save table contextmenu directionality",
          "emoticons template paste textcolor colorpicker textpattern"
        ],
        toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image",
        toolbar2: "print preview media | forecolor backcolor emoticons",
        image_advtab: true,
        file_picker_callback: function(callback, value, meta) {
          if (meta.filetype == 'image') {
            $('#upload').trigger('click');
            $('#upload').on('change', function() {
              var file = this.files[0];
              var reader = new FileReader();
              reader.onload = function(e) {
                callback(e.target.result, {
                  alt: ''
                });
              };
              reader.readAsDataURL(file);
            });
          }
        },
        templates: [{
          title: 'Test template 1',
          content: 'Test 1'
        }, {
          title: 'Test template 2',
          content: 'Test 2'
        }]
      });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>