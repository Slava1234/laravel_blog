<?php $__env->startSection('title', 'Contacts'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <h2><?php echo e($category_name); ?></h2>
        <div class="col-md-8">
            <?php if(count($posts) > 0): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="post">
                        <a class="post-title" href="<?php echo e(url('./blog/'.$post->slug)); ?>">
                            <h3 ><?php echo e($post->title); ?></h3>
                        </a>
                        <p><?php echo e(substr(strip_tags($post->body), 0,300)); ?> <?php echo e(strlen(strip_tags($post->body)) > 300? "...": ""); ?></p>
                    </div>
                    <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h4>В этой категории пока нет записей</h4>
            <?php endif; ?>

        </div>
        <div class="col-md-3 col-md-offset-1">
            <h3 class="category-h3">Категории</h3>
            <ul class="list-group">
                  <?php $__currentLoopData = $catpostsnum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('category.index', $category->name )); ?>" class="category-links-list">
                        <!-- Выделяем выбранную категорию как category-selected-active -->
                        <?php if($category_name == $category->name): ?>
                          <li class="category-selected-active list-group-item justify-content-between category-li-list">
                            <?php echo e($category->name); ?>

                            <span class="badge badge-default badge-pill">
                                <?php echo e($category->posts->count()); ?>

                            </span>
                          </li>
                        <?php else: ?>
                            <li class="list-group-item justify-content-between category-li-list">
                              <?php echo e($category->name); ?>

                              <span class="badge badge-default badge-pill">
                                  <?php echo e($category->posts->count()); ?>

                              </span>
                            </li>
                        <?php endif; ?>
                    </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>



        </div>
    </div>
    <div class="text-center">
        <?php echo $posts->links(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>