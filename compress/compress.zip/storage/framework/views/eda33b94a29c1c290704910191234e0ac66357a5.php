<?php $__env->startSection('title', 'Edit blog post'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <!-- Form binding -->
        <!-- !!!! means we are not echoing out we just need to execute some code -->
        <!--1:param is Model object, 2: param is all the options you want-->

        <?php echo Form::model($post, ['route' => ['posts.update', $post->id], "method" => "PUT"]); ?>

            <div class="col-md-8">
                <?php echo e(Form::label("title", "Название:")); ?>

                <?php echo e(Form::text('title', null, ["class" => "form-control input-lg"])); ?>


                <?php echo e(Form::label("slug", "URL Слог:", ["class" => 'form-spacing-top'])); ?>

                <?php echo e(Form::text('slug', null, ["class" => "form-control input-lg"])); ?>


                <?php echo e(Form::label('category_id', 'Категория: ', ['class' => 'btn-h1-spacing'])); ?>

                <select class="form-control" name="category_id">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php echo e(Form::label("body", "Текст:", ["class" => "form-spacing-top"])); ?>

                <?php echo e(Form::textarea('body', null, ["class" => "form-control"])); ?>

            </div>

            <div class="col-md-4">
                <div class="well">
                    <dl class="dl-horizontal">
                        <dt>Создан:</dt>
                        <dd><?php echo e(date('M j, Y H:i', strtotime($post->created_at))); ?></dd>
                    </dl>
                    <dl class="dl-horizontal">
                        <dt>Обновлен:</dt>
                        <dd><?php echo e(date('M j, Y H:i', strtotime($post->updated_at))); ?></dd>
                    </dl>
                    <hr>
                    <div class="row">
                        <div class="col-sm-6">
                            <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-danger btn-block">Отмена</a>
                        </div>
                        <div class="col-sm-6">
                           <?php echo e(Form::submit('Сохранить', ["class" => "btn btn-success btn-block"])); ?>

                        </div>
                    </div>
                </div>
            </div>
        <?php echo Form::close(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(url('public/tinymce/tinymce.min.js')); ?>"></script>
    <script>
        tinymce.init({
            selector: "textarea",
            plugins: 'image link lists table textcolor media imagetools colorpicker emoticons wordcount'

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>