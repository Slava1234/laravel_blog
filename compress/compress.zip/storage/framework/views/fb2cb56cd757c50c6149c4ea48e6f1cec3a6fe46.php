<?php $__env->startSection('title', 'Contacts'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h1>Contact me</h1>
            <hr>
            <form action="">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input id="email" name="email" class="form-control" type="text">
                </div>
                <div class="form-group">
                    <label for="subject">Subject:</label>
                    <input id="subject" name="subject" class="form-control" type="text">
                </div>
                <div class="form-group">
                    <label for="Message">Message:</label>
                    <textarea name="Message" id="Message" class="form-control" placeholder="Your message here..."></textarea>
                </div>
                <input type="submit" value="Send message" class="btn btn-success">
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>